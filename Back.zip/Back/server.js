const express = require('express')
const bodyParser = require('body-parser')
const mongoose = require('mongoose')
const passport = require('passport')
const morgan = require('morgan')
const cors = require('cors')
const path = require('path')

const keys = require('./config/keys')

const app = express()

// CORS_ORIGIN accepts a comma-separated list (e.g. "https://myapp.vercel.app,http://localhost:3000")
// so the same server config works for local dev and multiple deployed frontend URLs (prod + preview).
const allowedOrigins = (process.env.CORS_ORIGIN || 'http://localhost:3000')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean)

app.use(cors({
  origin: allowedOrigins,
  credentials: true
}))

// раздаёт загруженные файлы (аватарки и т.п.) по /uploads/...
app.use('/uploads', express.static(path.join(__dirname, 'uploads')))

mongoose.connect(keys.mongoUrl, { dbName: 'Breddit' })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log(err))

app.use(morgan('dev'))
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())

app.use(passport.initialize())
require('./middleware/passport')(passport)

app.use('/api/auth', require('./routes/auth'))
app.use('/api/posts', require('./routes/posts'))
app.use('/api/categories', require('./routes/categories'))
app.use('/api/comments', require('./routes/comments'))
app.use('/api/search', require('./routes/search'))
app.use('/api/votes', require('./routes/votes'))
app.use('/api/users', require('./routes/users'))
app.use('/api/notifications', require('./routes/notification'))

app.get('/', function (req, res) {
    res.send('Breddit backend is running')
})

app.use((req, res) => {
    res.status(404).json({ success: false, message: 'Route not found' })
})

app.use((err, req, res, next) => {
    console.error(err)
    res.status(err.statusCode || 500).json({
        success: false,
        message: err.message || 'Server error'
    })
})

if (require.main === module) {
    const http = require('http')
    const httpServer = http.createServer(app)
    require('./utils/socket').initSocket(httpServer, allowedOrigins)
    const PORT = process.env.PORT || 4000
    httpServer.listen(PORT, () => console.log(`Server started on ${PORT} (HTTP + WebSocket)`))
}

module.exports = app